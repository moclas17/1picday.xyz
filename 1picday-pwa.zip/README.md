# 1picday - One Photo Every Day

A mobile-first PWA for capturing one photo per day and building your visual story.

## Features

- ✨ Magic link authentication (mocked for frontend)
- 📸 Upload one photo per day
- 📅 Timeline view of all your photos
- 🎨 7-day recap grid
- 🌓 Dark mode with system preference support
- 📱 PWA with installable, native-app-like UI
- 👑 Pro upgrade flow (Stripe mocked)
- 🔒 Free tier: first 7 photos free

## Tech Stack

- Next.js 14+ (App Router)
- TypeScript
- Tailwind CSS v4
- PWA support with manifest

## Getting Started

This is a **frontend-only** version with all backend functionality mocked for rapid UI development.

### Installation

```bash
npm install
```

### Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the app.

### Installing as PWA

1. Open the app in Chrome/Safari on mobile
2. Tap "Add to Home Screen"
3. The app will install as a native-like application

## Project Structure

```
app/
  ├── page.tsx           # Landing page
  ├── login/             # Magic link login
  ├── app/               # Home timeline
  ├── recap/             # 7-day recap grid
  └── settings/          # Account & plan settings

components/
  ├── app-header.tsx     # Top navigation with theme toggle
  ├── bottom-nav.tsx     # Bottom tab navigation
  ├── photo-card.tsx     # Photo display card
  ├── theme-toggle.tsx   # Dark mode toggle
  └── upgrade-dialog.tsx # Pro upgrade modal

public/
  ├── manifest.webmanifest
  └── icons/
```

## Color Palette

The app uses a custom color system defined in `globals.css`:

**Light Mode:**
- Ink: #111111 (text)
- Paper: #FAFAFA (background)
- Mist: #E5E5E5 (borders)
- Ash: #9A9A9A (muted text)
- Stone: #6F6F6F (secondary text)
- Moss: #5F7A6A (primary/brand)
- Sun: #E6C97A (accent)

**Dark Mode:**
- Paper: #0B0F0D (background)
- Ink: #F2F2F2 (text)
- Mist: #1C2420 (borders)
- Ash: #A8B0AA (muted text)
- Stone: #7F8A84 (secondary text)
- Moss: #7FA693 (primary/brand)
- Sun: #E6C97A (accent)

## Mocked Features

All backend interactions are currently mocked:

- **Authentication**: Auto-redirects after "sending" magic link
- **Photo uploads**: Uses local file picker, doesn't persist
- **Stripe**: Shows upgrade dialog, alerts instead of checkout
- **Database**: Static mock data in components

## Next Steps for Production

To make this production-ready, you'll need to:

1. Set up Supabase with auth and database
2. Configure Amazon S3 for photo storage
3. Implement real Stripe integration
4. Add proper error handling
5. Set up environment variables
6. Configure service worker for offline support

See the original spec for complete backend requirements.

## License

MIT
