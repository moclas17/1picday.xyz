"use client"

import { BottomNav } from "@/components/bottom-nav"
import { AppHeader } from "@/components/app-header"

// Mock last 7 days
const MOCK_RECAP = [
  { date: "2025-01-15", url: "/sunset.jpg" },
  { date: "2025-01-14", url: "/steaming-coffee-cup.png" },
  { date: "2025-01-13", url: "/lush-forest-stream.png" },
  { date: "2025-01-12", url: "/diverse-food-spread.png" },
  { date: "2025-01-11", url: "/tabby-cat-sunbeam.png" },
  { date: "2025-01-10", url: "/vibrant-cityscape.png" },
  { date: "2025-01-09", url: "/abstract-fluid-art.png" },
]

export default function RecapPage() {
  return (
    <div className="min-h-screen bg-[var(--paper)] pb-20">
      <AppHeader />

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-[var(--ink)]">Last 7 Days</h1>
          <p className="text-[var(--stone)]">Your week at a glance</p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {MOCK_RECAP.map((photo) => (
            <div
              key={photo.date}
              className="relative aspect-square rounded-[var(--radius)] overflow-hidden bg-[var(--mist)]"
            >
              <img
                src={photo.url || "/placeholder.svg"}
                alt={`Photo from ${photo.date}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                <p className="text-white text-sm font-medium">
                  {new Date(photo.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </p>
              </div>
            </div>
          ))}
        </div>

        {MOCK_RECAP.length === 0 && (
          <div className="text-center py-12 space-y-2">
            <p className="text-[var(--stone)]">No photos yet</p>
            <p className="text-sm text-[var(--ash)]">Start capturing your daily moments</p>
          </div>
        )}
      </main>

      <BottomNav active="recap" />
    </div>
  )
}
