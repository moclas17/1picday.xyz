"use client"

import { useState } from "react"
import { Upload, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { BottomNav } from "@/components/bottom-nav"
import { AppHeader } from "@/components/app-header"
import { PhotoCard } from "@/components/photo-card"
import { UpgradeDialog } from "@/components/upgrade-dialog"

// Mock data
const MOCK_PHOTOS = [
  { id: "1", date: "2025-01-15", url: "/sunset.jpg", note: "Beautiful sunset today" },
  { id: "2", date: "2025-01-14", url: "/steaming-coffee-cup.png", note: "Morning coffee ritual" },
  { id: "3", date: "2025-01-13", url: "/lush-forest-stream.png", note: "Nature walk" },
  { id: "4", date: "2025-01-12", url: "/diverse-food-spread.png", note: "Homemade pasta" },
  { id: "5", date: "2025-01-11", url: "/tabby-cat-sunbeam.png", note: "Luna being cute" },
]

export default function AppPage() {
  const [photos, setPhotos] = useState(MOCK_PHOTOS)
  const [showUpgrade, setShowUpgrade] = useState(false)
  const isPro = false
  const photosCount = photos.length
  const remainingFree = Math.max(0, 7 - photosCount)

  const handleUpload = () => {
    if (!isPro && photosCount >= 7) {
      setShowUpgrade(true)
      return
    }

    // Mock upload
    const input = document.createElement("input")
    input.type = "file"
    input.accept = "image/*"
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        const url = URL.createObjectURL(file)
        const today = new Date().toISOString().split("T")[0]
        setPhotos([{ id: Date.now().toString(), date: today, url, note: "" }, ...photos])
      }
    }
    input.click()
  }

  const todayPhoto = photos.find((p) => p.date === new Date().toISOString().split("T")[0])

  return (
    <>
      <div className="min-h-screen bg-[var(--paper)] pb-20">
        <AppHeader />

        <main className="max-w-2xl mx-auto px-4 py-6 space-y-6">
          {/* Today's photo section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-[var(--ink)]">Today</h2>
              {!isPro && (
                <span className="text-sm text-[var(--ash)]">
                  {remainingFree > 0 ? `${remainingFree} of 7 free left` : "Free limit reached"}
                </span>
              )}
            </div>

            {!todayPhoto ? (
              <div className="border-2 border-dashed border-[var(--mist)] rounded-[var(--radius)] p-12 flex flex-col items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-[var(--mist)] flex items-center justify-center">
                  <Camera className="w-8 h-8 text-[var(--ash)]" />
                </div>
                <div className="text-center space-y-2">
                  <p className="font-medium text-[var(--ink)]">No photo yet today</p>
                  <p className="text-sm text-[var(--stone)]">Capture your daily moment</p>
                </div>
                <Button onClick={handleUpload} className="bg-[var(--moss)] text-[var(--paper)] hover:opacity-90">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Photo
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <PhotoCard photo={todayPhoto} />
                <p className="text-sm text-center text-[var(--stone)]">{"You've captured today's moment ✓"}</p>
              </div>
            )}
          </div>

          {/* Timeline */}
          {photos.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold text-[var(--ink)]">Your Timeline</h2>
              <div className="grid gap-4">
                {photos.map((photo) => (
                  <PhotoCard key={photo.id} photo={photo} />
                ))}
              </div>
            </div>
          )}
        </main>

        <BottomNav active="home" />
      </div>

      <UpgradeDialog open={showUpgrade} onOpenChange={setShowUpgrade} />
    </>
  )
}
